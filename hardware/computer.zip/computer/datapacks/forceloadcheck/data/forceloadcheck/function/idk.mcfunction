execute store success score i fc run forceload query ~ ~

execute if score i fc matches 0 run return 0

execute positioned ~-8 0 ~-8 unless entity @e[tag=fc_p, distance=..1] run summon marker ~ ~ ~ {Tags:["fc_p"]}
execute positioned ~-8 0 ~8 unless entity @e[tag=fc_p, distance=..1] run summon marker ~ ~ ~ {Tags:["fc_p"]}
execute positioned ~8 0 ~-8 unless entity @e[tag=fc_p, distance=..1] run summon marker ~ ~ ~ {Tags:["fc_p"]}
execute positioned ~8 0 ~8 unless entity @e[tag=fc_p, distance=..1] run summon marker ~ ~ ~ {Tags:["fc_p"]}