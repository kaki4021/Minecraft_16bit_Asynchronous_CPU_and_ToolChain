kill @e[tag=fc_p]

summon marker 0 0 0 {Rotation:[0F,0F],Tags:["fc1"]}
summon marker 0 0 0 {Rotation:[180F,0F],Tags:["fc1"]}
summon marker 0 0 0 {Rotation:[90F,0F],Tags:["fc2"]}
summon marker 0 0 0 {Rotation:[270F,0F],Tags:["fc2"]}

scoreboard objectives add fc dummy
scoreboard players set _10 fc 16
scoreboard players set _16 fc 16

summon marker 0 100 0 {Tags:["fc_c"]}
execute store result score x fc run data get entity @a[limit=1] Pos[0]
execute store result score z fc run data get entity @a[limit=1] Pos[2]

# 좌표 정렬
scoreboard players operation x fc /= _16 fc
scoreboard players operation x fc *= _16 fc

scoreboard players operation z fc /= _16 fc
scoreboard players operation z fc *= _16 fc

execute store result entity @e[limit=1, tag=fc_c] Pos[0] double 1.0 run scoreboard players get x fc


execute positioned as @e[tag=fc_c] rotated as @e[tag=fc1] positioned ^ ^ ^256 rotated as @e[tag=fc1] positioned ^ ^ ^128 rotated as @e[tag=fc1] positioned ^ ^ ^64 rotated as @e[tag=fc1] positioned ^ ^ ^32 rotated as @e[tag=fc1] positioned ^ ^ ^16 rotated as @e[tag=fc1] positioned ^ ^ ^8 rotated as @e[tag=fc2] positioned ^ ^ ^256 rotated as @e[tag=fc2] positioned ^ ^ ^128 rotated as @e[tag=fc2] positioned ^ ^ ^64 rotated as @e[tag=fc2] positioned ^ ^ ^32 rotated as @e[tag=fc2] positioned ^ ^ ^16 rotated as @e[tag=fc2] positioned ^ ^ ^8 run function forceloadcheck:idk


kill @e[tag=fc_c]

scoreboard objectives remove fc

kill @e[tag=fc1]
kill @e[tag=fc2]

tellraw @a [{"text":"[","color":"white"},{"text":"FORCELOAD CHECK","color":"green"},{"text":" loaded]","color":"white"}]
